#include <stdio.h>
#include <stdlib.h>

void help() {
  printf ("Usage: ./visualize xmin xmax ymin ymax input.dat output.dat\n");
}

int main ( int argc, char *argv[] ) {
  const int nbins = 20;
  int grid[nbins][nbins] = {{0}};
  double x, y;
  double xmin, xmax;
  double ymin, ymax;
  double xbinwidth, ybinwidth;
  FILE *output;
  FILE *input;
  int xbin, ybin;

  if ( argc != 7 ) {
    help();
    exit(1);
  }

  xmin = atof(argv[1]);
  xmax = atof(argv[2]);
  ymin = atof(argv[3]);
  ymax = atof(argv[4]);
  input = fopen ( argv[5],"r" );
  output = fopen ( argv[6],"w" );

  xbinwidth = (xmax - xmin)/nbins;
  ybinwidth = (ymax - ymin)/nbins;


	// Insert missing pieces here.


  fclose ( input );
  fclose ( output );

}
