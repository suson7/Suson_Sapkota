#include <stdio.h>
#include <stdlib.h>
#include <math.h>
double findmax ( double x, double xmax, int n ) {
  if ( n == 0 ) {
    xmax = x;
  } else {
    if ( x > xmax ) {
      xmax = x;
    }
  }
  return ( xmax );
}
double findmin ( double x, double xmin, int n ) {
  if ( n == 0 ) {
    xmin = x;
  } else {
    if ( x < xmin ) {
      xmin = x;
    }
  }
  return ( xmin );
}
void help () {
  printf ( "Usage: ./analyze filename\n" );
}
int main ( int argc, char *argv[] ) {

	// Insert missing pieces here.

}
